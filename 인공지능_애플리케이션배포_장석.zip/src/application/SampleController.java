package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class SampleController implements Initializable {

	@FXML
	private TextArea textArea;
	@FXML
	private Label currentDateTime;
	@FXML
	private CheckMenuItem line_check;
	@FXML
	public void about() throws IOException {

		Stage secondaryStage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("info.fxml"));
		Scene scene = new Scene(root, 500, 400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		secondaryStage.setResizable(false);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("�޸��� ����");
		secondaryStage.show();

	}

	@FXML
	public void autoline() {
		if (line_check.isSelected() == true) {
			textArea.wrapTextProperty().set(true);
		} else {
			textArea.wrapTextProperty().set(false);
		}
	}

	public void handleSave(ActionEvent e) {
		FileChooser fileChooser = new FileChooser();
		File file = fileChooser.showSaveDialog(textArea.getScene().getWindow());
		if (file != null) {
			saveFile(file);
		}
	}

	private void saveFile(File file) {
		try {
			FileWriter writer = null;
			writer = new FileWriter(file);
			writer.write(textArea.getText().replaceAll("\n", "\r\n"));
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void handleOpen(ActionEvent e) {
		FileChooser fileChooser = new FileChooser();
		File file = fileChooser.showOpenDialog(textArea.getScene().getWindow());
		getTextFromFile(file);
	}

	public void getTextFromFile(File txtFile) {
		String text;
		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(new FileInputStream(txtFile)));
			String line;
			while ((line = br.readLine()) != null) {
				textArea.appendText(line + "\n");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void handleClose(ActionEvent e) {
		Platform.exit();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		Thread thread = new Thread() {
			public void run() {
				while (true) {
					try {
						Date now = Calendar.getInstance().getTime();
						String s = MessageFormat.format("{0,date,yyyy-MM-dd HH:mm:ss}", now);
						Platform.runLater(() -> {
							currentDateTime.setText(s);
						});
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};
		thread.start();
	}
}